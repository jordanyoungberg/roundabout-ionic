angular.module('starter.directives', [])

.directive('map', function() {
  return {
    restrict: 'E',
    scope: {
      onCreate: '&'
    },
    link: function ($scope, $element, $attr) {
      function initialize() {
				
				var MY_MAPTYPE_ID = 'custom_style';
				
				var mapStyle = [
    {
        "featureType": "administrative",
        "elementType": "labels.text.fill",
        "stylers": [
            {
                "color": "#444444"
            }
        ]
    },
    {
        "featureType": "landscape",
        "elementType": "all",
        "stylers": [
            {
                "color": "#f2f2f2"
            }
        ]
    },
    {
        "featureType": "poi",
        "elementType": "all",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "road",
        "elementType": "all",
        "stylers": [
            {
                "saturation": -100
            },
            {
                "lightness": 45
            }
        ]
    },
    {
        "featureType": "road.highway",
        "elementType": "all",
        "stylers": [
            {
                "visibility": "simplified"
            }
        ]
    },
    {
        "featureType": "road.arterial",
        "elementType": "labels.icon",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "transit",
        "elementType": "all",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "water",
        "elementType": "all",
        "stylers": [
            {
                "color": "#7ed0e0"
            },
            {
                "visibility": "on"
            }
        ]
    }
];
				
        var mapOptions = {
          center: new google.maps.LatLng(43.07493, -89.381388),
          zoom: 12,
					mapTypeControlOptions: {
          mapTypeId: [google.maps.MapTypeId.ROADMAP, MY_MAPTYPE_ID]
        },
						mapTypeId: MY_MAPTYPE_ID
				};
        var map = new google.maps.Map($element[0], mapOptions);
				
				var styledMapOptions = {
					name: 'Custom Style'
				};
				
				var customMapType = new google.maps.StyledMapType(mapStyle, styledMapOptions);
				
				map.mapTypes.set(MY_MAPTYPE_ID, customMapType);
  
        $scope.onCreate({map: map});

        // Stop the side bar from dragging when mousedown/tapdown on the map
        google.maps.event.addDomListener($element[0], 'mousedown', function (e) {
          e.preventDefault();
          return false;
        });
      }

      if (document.readyState === "complete") {
        initialize();
      } else {
        google.maps.event.addDomListener(window, 'load', initialize);
      }
    }
  }
});
