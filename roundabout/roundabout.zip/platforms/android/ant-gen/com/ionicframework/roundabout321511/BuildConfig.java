/** Automatically generated file. DO NOT MODIFY */
package com.ionicframework.roundabout321511;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}